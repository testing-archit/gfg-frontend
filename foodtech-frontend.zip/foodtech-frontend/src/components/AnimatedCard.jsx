// src/components/AnimatedCard.jsx

import React from 'react';
import { useSpring, animated } from 'react-spring';

const AnimatedCard = ({ children }) => {
  const styles = useSpring({
    to: { opacity: 1, transform: 'translateY(0)' },
    from: { opacity: 0, transform: 'translateY(20px)' },
    config: { duration: 500 },
  });

  return <animated.div style={styles}>{children}</animated.div>;
};

export default AnimatedCard;
