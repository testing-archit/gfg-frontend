// src/components/LoadingSpinner.jsx
import React from 'react';
import './LoadingSpinner.css'; // Define your spinner styles

const LoadingSpinner = () => {
  return <div className="loading-spinner">Loading...</div>;
};

export default LoadingSpinner;
