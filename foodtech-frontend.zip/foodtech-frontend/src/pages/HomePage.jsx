// src/pages/HomePage.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import './HomePage.css'; // Assuming you have a separate CSS file for styling

const HomePage = () => {
  return (
    <div className="homepage">
      <header>
        <h1>Welcome to FoodTech</h1>
        <p>Your AI-powered recipe recommender.</p>
        <nav>
          <Link to="/signup" className="nav-link">Sign Up</Link>
          <Link to="/login" className="nav-link">Log In</Link>
          <Link to="/recipe-search" className="nav-link">Search Recipes</Link>
        </nav>
      </header>
      <main>
        <section className="about">
          <h2>About Us</h2>
          <p>
            At FoodTech, we help you discover delicious recipes based on your
            ingredients and preferences. Join us today and make cooking
            enjoyable!
          </p>
        </section>
        <section className="features">
          <h2>Features</h2>
          <ul>
            <li>Personalized recipe recommendations</li>
            <li>Search by ingredients, preparation time, and more</li>
            <li>User-friendly interface for a seamless experience</li>
          </ul>
        </section>
      </main>
      <footer>
        <p>&copy; 2024 FoodTech. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default HomePage; // Ensure this line is present
