// src/pages/RecipeSearch.jsx

import React, { useState } from 'react';
import axios from 'axios';
import './RecipeSearch.css';

const RecipeSearch = () => {
  const [ingredients, setIngredients] = useState('');
  const [recipes, setRecipes] = useState([]);

  const handleSearch = async () => {
    try {
      const response = await axios.post('http://localhost:5000/api/recommendation', {
        user_ingredients: ingredients.split(','),
        user_prep_time: 30, // Example prep time
        user_cook_time: 30, // Example cook time
      });
      setRecipes(response.data);
    } catch (error) {
      console.error(error);
      alert('Error fetching recipes');
    }
  };

  return (
    <div className="recipe-search">
      <h2>Search for Recipes</h2>
      <input
        type="text"
        placeholder="Enter ingredients (comma separated)"
        value={ingredients}
        onChange={(e) => setIngredients(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>
      <div className="recipe-results">
        {recipes.length > 0 ? (
          recipes.map((recipe) => (
            <div key={recipe.unique_id} className="recipe-card">
              <h3>{recipe.TranslatedRecipeName}</h3>
              <p><strong>Ingredients:</strong> {recipe.TranslatedIngredients}</p>
              <p><strong>Preparation Time:</strong> {recipe.PrepTimeInMins} mins</p>
              <p><strong>Cooking Time:</strong> {recipe.CookTimeInMins} mins</p>
              <p><strong>Instructions:</strong> {recipe.TranslatedInstructions}</p>
              <img src={recipe.image_src} alt={recipe.TranslatedRecipeName} />
            </div>
          ))
        ) : (
          <p>No recipes found. Please try different ingredients.</p>
        )}
      </div>
    </div>
  );
};

export default RecipeSearch;
